import G1 from "../assets/images/G1.jpeg";
import G2 from "../assets/images/G2.jpeg";
import G3 from "../assets/images/G3.jpeg";
import G4 from "../assets/images/G4.jpeg";
import G5 from "../assets/images/G5.jpeg";
import G6 from "../assets/images/G6.jpg";
import G7 from "../assets/images/G7.jpeg";
import G8 from "../assets/images/G8.jpg";
import G9 from "../assets/images/G9.jpg";
import G10 from "../assets/images/G10.jpeg";
import G11 from "../assets/images/G11.jpg";
import G12 from "../assets/images/G12.jpg";
import G13 from "../assets/images/G13.jpg";
import G14 from "../assets/images/G14.jpeg";
import G15 from "../assets/images/G15.jpg";
import G16 from "../assets/images/G16.jfif";
import G17 from "../assets/images/G17.jpg";
import G18 from "../assets/images/G18.jpg";


const Gellary = [
  {
    id: 1,
    imagePath: G1,
  },
  {
    id: 2,
    imagePath: G2,
  },
  {
    id: 3,
    imagePath: G3,
  },
  {
    id: 4,
    imagePath: G4,
  },
  {
    id: 5,
    imagePath: G5,
  },
  {
    id: 6,
    imagePath: G6,
  },
  {
    id: 7,
    imagePath: G7,
  },
  {
    id: 8,
    imagePath: G8,
  },
  {
    id: 9,
    imagePath: G9,
  },
  {
    id: 10,
    imagePath: G10,
  },
  {
    id: 11,
    imagePath: G11,
  },
  {
    id: 12,
    imagePath: G12,
  },
  {
    id: 13,
    imagePath: G13,
  },
  {
    id: 14,
    imagePath: G14,
  },
  {
    id: 15,
    imagePath: G15,
  },
  {
    id: 16,
    imagePath: G16,
  },
  {
    id: 17,
    imagePath: G17,
  },
  {
    id: 18,
    imagePath: G18,
  },
];

export default Gellary;
