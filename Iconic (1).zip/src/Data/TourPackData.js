import tp1 from "../assets/images/inter.png"
import tp2 from "../assets/images/domestic.jpg"
import tp3 from "../assets/images/spritual.jpg"
const TourPackData = [
    {
           id: 1,
           imagePath: tp1,
           title: "International Tours",
       },
       {
        id: 2,
        imagePath: tp2,
        title: "Domestic Tours",
    },
    {
        id: 3,
        imagePath: tp3,
        title: "Spritual Tours",
    },

    ];
    export default TourPackData