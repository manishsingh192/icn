import { Typography } from '@mui/material'
import React from 'react'

const PageNotFound = () => {
  return (
    <>
      <Typography>Page Not Found</Typography>
    </>
  )
}

export default PageNotFound
